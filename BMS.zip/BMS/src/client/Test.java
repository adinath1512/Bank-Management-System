package client;

import serviceImple.Sbi;
import service.Rbi;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Scanner sch = new Scanner(System.in);
		Rbi r = new Sbi();
		while (true) {
			System.out.println("***Welcome To BMS***\n Enter your Choice\n"
					+ " 1.Creare New Account\n 2.Display Details\n 3.Deposite MOney\n "
					+ "4.Withdraw \n 5.Balance check\n 6.Exit");
			int c = sch.nextInt();
			if (c == 1) {
				r.createAccount();
				System.out.println("Account Create Successfully");
			}

			else if (c == 2) {
				r.displayAllDetails();

			} else if (c == 3) {
				r.depositeMoney();
			} else if (c == 4) {
				r.withdrawal();

			} else if (c == 5) {
				r.balanceCheck();
			} else if (c == 6) {
				break;
			} else {
				System.out.println("Invalid Choice");
			}
		}

	}

}
