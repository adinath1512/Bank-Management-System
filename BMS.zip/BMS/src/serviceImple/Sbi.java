package serviceImple;


import java.util.Scanner;

import model.Account;
import service.Rbi;

public class Sbi implements Rbi {
	Scanner sc=new Scanner(System.in);
	Account acc=new Account();

	@Override
	public void createAccount() {
		System.out.println("Enter Account no:-");
		int ac=sc.nextInt();
		System.out.println("Enter Name :-");
		String nm=sc.next();
		System.out.println("Enter Mobile No:-");
		String mb=sc.next();
		System.out.println("Enter Adhar No:-");
		String ad=sc.next();
		System.out.println("Enter Gender :_");
		String gn=sc.next();
		System.out.println("Enter Your Age:-");
		int  age=sc.nextInt();
		System.out.println(" Enter Main balance");
		Double bl=sc.nextDouble();
		acc.setAccNo(ac);
		acc.setName(nm);
		acc.setMobNo(mb);
		acc.setAdharNo(ad);
		acc.setGender(gn);
	    acc.setAge(age);
	    acc.setBalance(bl);
		
		
		
		
	}

	@Override
	public void displayAllDetails() {
	 
		System.out.println("*****Account Details****");
		System.out.println(acc);
		
	}

	@Override
	public void depositeMoney() {
		System.out.println("Enter your deposite Money");
		double bal=sc.nextInt();
		double balance=acc.getBalance();
		balance=balance+bal;
		acc.setBalance(balance);
		System.out.println("Balance Deposite Successfuly");
	}

	
	

	@Override
	public void withdrawal() {
		System.out.println("Enter the withdraw amount");
		 double wt=acc.getBalance();
		 double bal=sc.nextDouble();
		if(wt>bal) {
			wt=wt-bal;
			acc.setBalance(wt);
			System.out.println("Amount Withdrawn Successfully");
		}else {
			System.out.println("Insufficient Balance");
			
		}
		
	}

	@Override
	public void balanceCheck() {
		System.out.println("Your Account Balance is"+acc.getBalance());
		
	}
	

	
	

}
